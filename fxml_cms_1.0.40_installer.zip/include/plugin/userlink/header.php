<?php
if(!defined('XMLCMS')) exit();