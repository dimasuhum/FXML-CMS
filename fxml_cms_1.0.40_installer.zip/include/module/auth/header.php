<?php
if(isset($_COOKIE["sid"])) auth_user_sid($_COOKIE["sid"]);